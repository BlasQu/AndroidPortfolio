package com.example.simpleshoppingrework.util.data

data class Details(val product: String, val count: String, var checked: Boolean = false)